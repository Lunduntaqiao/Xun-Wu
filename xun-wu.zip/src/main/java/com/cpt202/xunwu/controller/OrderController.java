package com.cpt202.xunwu.controller;

import java.util.List;

import com.cpt202.xunwu.bean.ComResult;
import com.cpt202.xunwu.bean.ProdCart;
import com.cpt202.xunwu.model.OrderList;
import com.cpt202.xunwu.service.OrderService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class OrderController {

    @Autowired
    private OrderService orderService;

    @PostMapping(value = "GetOrder")
    public List GetOrder(@RequestParam(name = "userName") String userName,
            @RequestParam(name = "ProductState") String ProductState,
            @RequestParam(name = "Identity") String Identity) {
        return orderService.getOrder(userName, ProductState, Identity);
    }

    @PostMapping(value = "SetOrder")
    public ComResult SetOrder(@RequestParam(name = "userName") String userName, @RequestBody OrderList orderList) {
        return orderService.setOrder(userName, orderList);
    }

    @PostMapping(value = "GetaOrder")
    public List GetAOrder(@RequestParam(name = "orderId") long orderId) {
        return orderService.getAOrder(orderId);
    }

    @PostMapping(value = "SetOrderState")
    public ComResult SetOrderState(@RequestParam(name = "orderId") long orderId,
            @RequestParam(name = "orderState") String orderState) {
        return orderService.setOrderState(orderId, orderState);
    }
}
