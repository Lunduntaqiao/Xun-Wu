package com.cpt202.xunwu.bean;

public class Changepassword {
    private String changepassword;

    public String getChangepassword() {
        return changepassword;
    }

    public void setChangepassword(String changepassword) {
        this.changepassword = changepassword;
    }
}
