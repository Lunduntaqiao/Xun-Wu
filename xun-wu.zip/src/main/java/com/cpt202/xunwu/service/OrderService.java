package com.cpt202.xunwu.service;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.cpt202.xunwu.bean.ComResult;
import com.cpt202.xunwu.model.OrderList;
import com.cpt202.xunwu.model.Product;
import com.cpt202.xunwu.repository.OrderRepo;
import com.cpt202.xunwu.repository.ProductRepo;
import com.mysql.cj.x.protobuf.MysqlxCrud.Order;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class OrderService {

    @Autowired
    private OrderRepo orderRepo;

    @Autowired
    private ProductRepo productRepo;

    public List getOrder(String username, String ProductState, String Identity) {

        List<OrderList> OrderList = new ArrayList<>();
        if (Identity.equals("buyer"))
            OrderList.addAll(GetOrderBybuyer(username, ProductState));

        if (Identity.equals("seller"))
            OrderList.addAll(GetOrderByseller(username, ProductState));

        if (Identity.equals("")) {
            OrderList.addAll(GetOrderBybuyer(username, ProductState));
            OrderList.addAll(GetOrderByseller(username, ProductState));
        }
        return OrderList;
    }

    // find all information by buyer
    public List GetOrderBybuyer(String username, String ProductState) {
        List<OrderList> OrderList = new ArrayList<>();
        List<OrderList> aOrder = orderRepo.findAllByBuyer(username);
        for (int i = 0; i < aOrder.size(); i++) {
            String orderState = aOrder.get(i).getOrderState();
            if (!ProductState.equals("")) {
                if (orderState.equals(ProductState))
                    OrderList.add(aOrder.get(i));
            } else {
                OrderList.add(aOrder.get(i));
            }

        }
        return OrderList;
    }

    // find all information by seller
    public List GetOrderByseller(String username, String ProductState) {
        // System.out.println("ssssssssssss");
        List<OrderList> OrderList = new ArrayList<>();
        List<Product> existProduct = productRepo.findProductIdByProductPublishUserName(username);
        for (int j = 0; j < existProduct.size(); j++) {
            long productId = existProduct.get(j).getProductId();
            List<OrderList> existOrder = orderRepo.findOrderByProductId(productId);
            if (existOrder != null) {
                for (int x = 0; x < existOrder.size(); x++) {
                    String orderState = existOrder.get(x).getOrderState();
                    if (!ProductState.equals("")) {
                        if (orderState.equals(ProductState))
                            OrderList.add(existOrder.get(x));
                    } else
                        OrderList.add(existOrder.get(x));
                }
            }
        }
        return OrderList;
    }

    // set order
    public ComResult setOrder(String userName, OrderList orderList) {
        ComResult newComResult = new ComResult();
        // 获取当前时间
        Date day = new Date();
        orderList.setCreateDate(day);
        orderList.setOrderState("已付款");
        orderRepo.save(orderList);
        return newComResult;
    }


    // order details
    public List getAOrder(long orderId) {
        List<OrderList> OrderList = orderRepo.findAllByOrderId(orderId);
        return OrderList;
    }

    public ComResult setOrderState(long orderId, String orderState){
        ComResult newComResult = new ComResult();
        OrderList orderList = orderRepo.findOrderByOrderId(orderId);
        orderList.setOrderState(orderState);
        if(orderState.equals("已完成")){
            Date day = new Date();
            orderList.setFinishDate(day);
        }
        orderRepo.save(orderList);
        newComResult.setMessage("订单信息已更新");
        return newComResult;
    }
}
