package com.cpt202.xunwu;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class XunWuApplicationTests {

	@Test
	void contextLoads() {
	}

}
