let rootUrl = "http://47.103.203.188:9080";

//用户相关操作
let registerUrl = "/user/register";

let loginUrl = "/user/login";

let checkCodeUrl = "/checkCode";

let getUserUrl = "/user/getUser";

//对购物车操作
let joinProductUrl = "/operator/joinProduct";

let getJoinProductUrl = "/operator/getJoinProduct";

let removeJoinProductUrl = "/operator/removeJoinProduct";

//对订单操作
let buyProductUrl = "/operator/buyProduct";

let getBuyProductUrl = "/operator/getBuyProduct";

let removeBuyProductUrl = "/operator/removeBuyProduct";




